-- Run this script in MySQL Workbench.
CREATE DATABASE IF NOT EXISTS hotel_db;
USE hotel_db;

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash CHAR(64) NOT NULL,
    role ENUM('admin', 'user') NOT NULL DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(200),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS rooms (
    room_id INT PRIMARY KEY,
    room_type VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    ac_type ENUM('AC', 'Non-AC') NOT NULL,
    status ENUM('Available', 'Booked') DEFAULT 'Available'
);

CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    room_id INT NOT NULL,
    days INT NOT NULL,
    total_bill DECIMAL(10,2) NOT NULL,
    status ENUM('Booked', 'Cancelled', 'Checked Out') DEFAULT 'Booked',
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

INSERT IGNORE INTO rooms (room_id, room_type, price, ac_type, status)
VALUES
(101, 'Single', 1000, 'Non-AC', 'Available'),
(102, 'Single', 1500, 'AC', 'Available'),
(103, 'Single', 1000, 'Non-AC', 'Available'),
(201, 'Double', 1300, 'Non-AC', 'Available'),
(202, 'Double', 1800, 'AC', 'Available'),
(203, 'Double', 1800, 'AC', 'Available'),
(301, 'Deluxe', 2200, 'Non-AC', 'Available'),
(302, 'Deluxe', 3000, 'AC', 'Available');

-- Bootstrap the first administrator:
-- 1) Register an ordinary user through the application.
-- 2) Find that username's user_id, then promote it to admin:
-- UPDATE users SET role = 'admin' WHERE username = 'YOUR_CHOSEN_USERNAME';
-- Run this promotion only as the database administrator.
