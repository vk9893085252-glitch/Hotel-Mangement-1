#include <iostream>
#include <string>
#include <memory>
#include <limits>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <mysql_driver.h>
#include <mysql_connection.h>
#include <cppconn/statement.h>
#include <cppconn/prepared_statement.h>
#include <cppconn/resultset.h>
#include <cppconn/exception.h>
#include <openssl/sha.h>

using namespace std;

sql::mysql::MySQL_Driver* driver = nullptr;
unique_ptr<sql::Connection> con;

string currentUsername;
string currentRole;
int currentUserId = 0;
int currentCustomerId = 0;

// ---------------- DATABASE CONNECTION ----------------

void connectDatabase() {
    driver = sql::mysql::get_mysql_driver_instance();

    con.reset(driver->connect(
        "tcp://127.0.0.1:3306",
        "root",
        "YOUR_MYSQL_PASSWORD"
    ));

    con->setSchema("hotel_db");

    cout << "\nDatabase connected successfully!\n";
}

// ---------------- PASSWORD HASH ----------------
// Learning example only. SHA-256 alone is not suitable for production password storage.
// Use Argon2id or bcrypt for a real application.

string hashPassword(const string& password) {
    unsigned char hash[SHA256_DIGEST_LENGTH];

    SHA256(
        reinterpret_cast<const unsigned char*>(password.c_str()),
        password.size(),
        hash
    );

    stringstream ss;

    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        ss << hex << setw(2) << setfill('0')
           << static_cast<int>(hash[i]);
    }

    return ss.str();
}

// ---------------- INPUT HELPERS ----------------

int readInt(const string& message) {
    int value;

    while (true) {
        cout << message;

        if (cin >> value) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }

        cout << "Invalid input. Enter a number.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

string readText(const string& message) {
    string value;
    cout << message;
    getline(cin, value);
    return value;
}

// ---------------- USER REGISTRATION ----------------

void registerUser(bool adminCreatingUser = false) {
    string username = readText("Enter username: ");
    string password = readText("Enter password: ");

    if (username.empty() || password.empty()) {
        cout << "Username and password cannot be empty.\n";
        return;
    }

    string role = "user";

    if (adminCreatingUser) {
        role = readText("Enter role (admin/user): ");

        if (role != "admin" && role != "user") {
            cout << "Invalid role.\n";
            return;
        }
    }

    try {
        unique_ptr<sql::PreparedStatement> ps(
            con->prepareStatement(
                "INSERT INTO users (username, password_hash, role) "
                "VALUES (?, ?, ?)"
            )
        );

        ps->setString(1, username);
        ps->setString(2, hashPassword(password));
        ps->setString(3, role);
        ps->executeUpdate();

        cout << "Account created successfully!\n";

    } catch (sql::SQLException&) {
        cout << "Could not create account. The username may already exist.\n";
    }
}

// ---------------- LOGIN ----------------

bool login() {
    string username = readText("Username: ");
    string password = readText("Password: ");

    unique_ptr<sql::PreparedStatement> ps(
        con->prepareStatement(
            "SELECT user_id, username, role "
            "FROM users WHERE username = ? AND password_hash = ?"
        )
    );

    ps->setString(1, username);
    ps->setString(2, hashPassword(password));

    unique_ptr<sql::ResultSet> rs(ps->executeQuery());

    if (!rs->next()) {
        cout << "Invalid username or password.\n";
        return false;
    }

    currentUserId = rs->getInt("user_id");
    currentUsername = rs->getString("username");
    currentRole = rs->getString("role");

    cout << "\nLogin successful!\n";
    cout << "Welcome, " << currentUsername << "!\n";
    cout << "Role: " << currentRole << "\n";

    return true;
}

// ---------------- CUSTOMER PROFILE ----------------

void createCustomerProfile() {
    unique_ptr<sql::PreparedStatement> ps(
        con->prepareStatement(
            "SELECT customer_id FROM customers WHERE user_id = ?"
        )
    );

    ps->setInt(1, currentUserId);

    unique_ptr<sql::ResultSet> rs(ps->executeQuery());

    if (rs->next()) {
        currentCustomerId = rs->getInt("customer_id");
        return;
    }

    string name = readText("Enter your full name: ");
    string phone = readText("Enter phone number: ");
    string address = readText("Enter address: ");

    unique_ptr<sql::PreparedStatement> insert(
        con->prepareStatement(
            "INSERT INTO customers (user_id, name, phone, address) "
            "VALUES (?, ?, ?, ?)"
        )
    );

    insert->setInt(1, currentUserId);
    insert->setString(2, name);
    insert->setString(3, phone);
    insert->setString(4, address);
    insert->executeUpdate();

    unique_ptr<sql::PreparedStatement> find(
        con->prepareStatement(
            "SELECT customer_id FROM customers WHERE user_id = ?"
        )
    );

    find->setInt(1, currentUserId);

    unique_ptr<sql::ResultSet> result(find->executeQuery());

    if (result->next()) {
        currentCustomerId = result->getInt("customer_id");
    }

    cout << "Customer profile created successfully!\n";
}

// ---------------- VIEW CUSTOMERS ----------------

void displayCustomers() {
    unique_ptr<sql::Statement> stmt(con->createStatement());

    unique_ptr<sql::ResultSet> rs(
        stmt->executeQuery(
            "SELECT customer_id, name, phone, address "
            "FROM customers ORDER BY customer_id"
        )
    );

    cout << "\nCUSTOMER LIST\n";
    cout << "-----------------------------------------------\n";

    while (rs->next()) {
        cout << "Customer ID: " << rs->getInt("customer_id")
             << "\nName: " << rs->getString("name")
             << "\nPhone: " << rs->getString("phone")
             << "\nAddress: " << rs->getString("address")
             << "\n-----------------------------------------------\n";
    }
}

// ---------------- SEARCH CUSTOMER ----------------

void searchCustomer() {
    int id = readInt("Enter customer ID: ");

    unique_ptr<sql::PreparedStatement> ps(
        con->prepareStatement(
            "SELECT customer_id, name, phone, address "
            "FROM customers WHERE customer_id = ?"
        )
    );

    ps->setInt(1, id);

    unique_ptr<sql::ResultSet> rs(ps->executeQuery());

    if (!rs->next()) {
        cout << "Customer not found.\n";
        return;
    }

    cout << "\nCustomer ID: " << rs->getInt("customer_id")
         << "\nName: " << rs->getString("name")
         << "\nPhone: " << rs->getString("phone")
         << "\nAddress: " << rs->getString("address") << "\n";
}

// ---------------- VIEW ROOMS ----------------

void showRooms(const string& query, const string& parameter = "") {
    unique_ptr<sql::PreparedStatement> ps(con->prepareStatement(query));

    if (!parameter.empty()) {
        ps->setString(1, parameter);
    }

    unique_ptr<sql::ResultSet> rs(ps->executeQuery());

    cout << "\nROOM LIST\n";
    cout << "-----------------------------------------------------\n";

    bool found = false;

    while (rs->next()) {
        found = true;

        cout << "Room ID: " << rs->getInt("room_id")
             << "\nType: " << rs->getString("room_type")
             << "\nPrice per day: Rs. " << rs->getDouble("price")
             << "\nCategory: " << rs->getString("ac_type")
             << "\nStatus: " << rs->getString("status")
             << "\n-----------------------------------------------------\n";
    }

    if (!found) {
        cout << "No matching rooms found.\n";
    }
}

void displayAllRooms() {
    showRooms(
        "SELECT room_id, room_type, price, ac_type, status "
        "FROM rooms ORDER BY room_id"
    );
}

void searchAvailableRooms() {
    showRooms(
        "SELECT room_id, room_type, price, ac_type, status "
        "FROM rooms WHERE status = 'Available' ORDER BY room_id"
    );
}

void searchRoomType() {
    string type = readText("Enter room type (Single/Double/Deluxe): ");

    showRooms(
        "SELECT room_id, room_type, price, ac_type, status "
        "FROM rooms WHERE room_type = ? AND status = 'Available'",
        type
    );
}

void searchACCategory() {
    string category = readText("Enter category (AC/Non-AC): ");

    if (category != "AC" && category != "Non-AC") {
        cout << "Invalid category.\n";
        return;
    }

    showRooms(
        "SELECT room_id, room_type, price, ac_type, status "
        "FROM rooms WHERE ac_type = ? AND status = 'Available'",
        category
    );
}

void searchTypeAndCategory() {
    string type = readText("Enter room type (Single/Double/Deluxe): ");
    string category = readText("Enter category (AC/Non-AC): ");

    if (category != "AC" && category != "Non-AC") {
        cout << "Invalid category.\n";
        return;
    }

    unique_ptr<sql::PreparedStatement> ps(
        con->prepareStatement(
            "SELECT room_id, room_type, price, ac_type, status "
            "FROM rooms WHERE room_type = ? AND ac_type = ? "
            "AND status = 'Available'"
        )
    );

    ps->setString(1, type);
    ps->setString(2, category);

    unique_ptr<sql::ResultSet> rs(ps->executeQuery());

    bool found = false;

    while (rs->next()) {
        found = true;

        cout << "\nRoom ID: " << rs->getInt("room_id")
             << "\nType: " << rs->getString("room_type")
             << "\nPrice: Rs. " << rs->getDouble("price")
             << "\nCategory: " << rs->getString("ac_type") << "\n";
    }

    if (!found) {
        cout << "No matching rooms available.\n";
    }
}

// ---------------- ADD ROOM ----------------

void addRoom() {
    int roomId = readInt("Enter new room ID: ");
    string type = readText("Enter type (Single/Double/Deluxe): ");

    double price;
    cout << "Enter price per day: ";
    if (!(cin >> price)) {
        cout << "Invalid price.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return;
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    string category = readText("Enter category (AC/Non-AC): ");

    if (price <= 0 ||
        (category != "AC" && category != "Non-AC") ||
        (type != "Single" && type != "Double" && type != "Deluxe")) {
        cout << "Invalid room details.\n";
        return;
    }

    unique_ptr<sql::PreparedStatement> ps(
        con->prepareStatement(
            "INSERT INTO rooms "
            "(room_id, room_type, price, ac_type, status) "
            "VALUES (?, ?, ?, ?, 'Available')"
        )
    );

    ps->setInt(1, roomId);
    ps->setString(2, type);
    ps->setDouble(3, price);
    ps->setString(4, category);

    try {
        ps->executeUpdate();
        cout << "Room added successfully!\n";
    } catch (sql::SQLException&) {
        cout << "Could not add room. Check the room ID.\n";
    }
}

// ---------------- BOOK ROOM ----------------

void bookRoom() {
    if (currentCustomerId == 0) {
        cout << "Customer profile not found.\n";
        return;
    }

    int roomId = readInt("Enter room ID to book: ");
    int days = readInt("Enter number of days: ");

    if (days <= 0) {
        cout << "Number of days must be positive.\n";
        return;
    }

    try {
        con->setAutoCommit(false);

        unique_ptr<sql::PreparedStatement> room(
            con->prepareStatement(
                "SELECT price, status FROM rooms "
                "WHERE room_id = ? FOR UPDATE"
            )
        );

        room->setInt(1, roomId);
        unique_ptr<sql::ResultSet> rs(room->executeQuery());

        if (!rs->next() || rs->getString("status") != "Available") {
            con->rollback();
            con->setAutoCommit(true);
            cout << "Room does not exist or is unavailable.\n";
            return;
        }

        double total = rs->getDouble("price") * days;

        unique_ptr<sql::PreparedStatement> booking(
            con->prepareStatement(
                "INSERT INTO bookings "
                "(customer_id, room_id, days, total_bill, status) "
                "VALUES (?, ?, ?, ?, 'Booked')"
            )
        );

        booking->setInt(1, currentCustomerId);
        booking->setInt(2, roomId);
        booking->setInt(3, days);
        booking->setDouble(4, total);
        booking->executeUpdate();

        unique_ptr<sql::PreparedStatement> update(
            con->prepareStatement(
                "UPDATE rooms SET status = 'Booked' WHERE room_id = ?"
            )
        );

        update->setInt(1, roomId);
        update->executeUpdate();

        con->commit();
        con->setAutoCommit(true);

        cout << "\nRoom booked successfully!\n";
        cout << "Room ID: " << roomId
             << "\nDays: " << days
             << "\nTotal amount: Rs. "
             << fixed << setprecision(2) << total << "\n";

    } catch (sql::SQLException&) {
        try {
            con->rollback();
            con->setAutoCommit(true);
        } catch (...) {
        }

        cout << "Booking failed. Please try again.\n";
    }
}

// ---------------- VIEW BOOKINGS ----------------

void viewBookings(bool adminView) {
    string query;

    if (adminView) {
        query =
            "SELECT b.booking_id, b.customer_id, c.name, b.room_id, "
            "b.days, b.total_bill, b.status "
            "FROM bookings b JOIN customers c "
            "ON b.customer_id = c.customer_id "
            "ORDER BY b.booking_id";
    } else {
        query =
            "SELECT b.booking_id, b.customer_id, c.name, b.room_id, "
            "b.days, b.total_bill, b.status "
            "FROM bookings b JOIN customers c "
            "ON b.customer_id = c.customer_id "
            "WHERE b.customer_id = ? ORDER BY b.booking_id";
    }

    unique_ptr<sql::PreparedStatement> ps(con->prepareStatement(query));

    if (!adminView) {
        ps->setInt(1, currentCustomerId);
    }

    unique_ptr<sql::ResultSet> rs(ps->executeQuery());
    bool found = false;

    cout << "\nBOOKING DETAILS\n";

    while (rs->next()) {
        found = true;

        cout << "\nBooking ID: " << rs->getInt("booking_id")
             << "\nCustomer: " << rs->getString("name")
             << "\nRoom ID: " << rs->getInt("room_id")
             << "\nDays: " << rs->getInt("days")
             << "\nBill: Rs. " << rs->getDouble("total_bill")
             << "\nStatus: " << rs->getString("status")
             << "\n-----------------------------\n";
    }

    if (!found) {
        cout << "No bookings found.\n";
    }
}

// ---------------- CANCEL BOOKING ----------------

void cancelBooking(bool adminMode) {
    int bookingId = readInt("Enter booking ID: ");

    try {
        con->setAutoCommit(false);

        string query =
            "SELECT room_id FROM bookings "
            "WHERE booking_id = ? AND status = 'Booked'";

        if (!adminMode) {
            query += " AND customer_id = ?";
        }

        query += " FOR UPDATE";

        unique_ptr<sql::PreparedStatement> ps(
            con->prepareStatement(query)
        );

        ps->setInt(1, bookingId);
        if (!adminMode) {
            ps->setInt(2, currentCustomerId);
        }

        unique_ptr<sql::ResultSet> rs(ps->executeQuery());

        if (!rs->next()) {
            con->rollback();
            con->setAutoCommit(true);
            cout << "Active booking not found.\n";
            return;
        }

        int roomId = rs->getInt("room_id");

        unique_ptr<sql::PreparedStatement> updateBooking(
            con->prepareStatement(
                "UPDATE bookings SET status = 'Cancelled' "
                "WHERE booking_id = ?"
            )
        );

        updateBooking->setInt(1, bookingId);
        updateBooking->executeUpdate();

        unique_ptr<sql::PreparedStatement> updateRoom(
            con->prepareStatement(
                "UPDATE rooms SET status = 'Available' WHERE room_id = ?"
            )
        );

        updateRoom->setInt(1, roomId);
        updateRoom->executeUpdate();

        con->commit();
        con->setAutoCommit(true);

        cout << "Booking cancelled successfully.\n";

    } catch (sql::SQLException&) {
        try {
            con->rollback();
            con->setAutoCommit(true);
        } catch (...) {
        }

        cout << "Could not cancel booking.\n";
    }
}

// ---------------- CHECK OUT ----------------

void checkOut() {
    int bookingId = readInt("Enter booking ID: ");

    try {
        con->setAutoCommit(false);

        unique_ptr<sql::PreparedStatement> ps(
            con->prepareStatement(
                "SELECT room_id FROM bookings "
                "WHERE booking_id = ? AND status = 'Booked' FOR UPDATE"
            )
        );

        ps->setInt(1, bookingId);
        unique_ptr<sql::ResultSet> rs(ps->executeQuery());

        if (!rs->next()) {
            con->rollback();
            con->setAutoCommit(true);
            cout << "Active booking not found.\n";
            return;
        }

        int roomId = rs->getInt("room_id");

        unique_ptr<sql::PreparedStatement> updateBooking(
            con->prepareStatement(
                "UPDATE bookings SET status = 'Checked Out' "
                "WHERE booking_id = ?"
            )
        );

        updateBooking->setInt(1, bookingId);
        updateBooking->executeUpdate();

        unique_ptr<sql::PreparedStatement> updateRoom(
            con->prepareStatement(
                "UPDATE rooms SET status = 'Available' WHERE room_id = ?"
            )
        );

        updateRoom->setInt(1, roomId);
        updateRoom->executeUpdate();

        con->commit();
        con->setAutoCommit(true);

        cout << "Checkout completed successfully.\n";

    } catch (sql::SQLException&) {
        try {
            con->rollback();
            con->setAutoCommit(true);
        } catch (...) {
        }

        cout << "Checkout failed.\n";
    }
}

// ---------------- GENERATE BILL ----------------

void generateBill(bool adminMode) {
    int bookingId = readInt("Enter booking ID: ");

    string query =
        "SELECT b.booking_id, c.name, b.room_id, b.days, b.total_bill, "
        "b.status FROM bookings b "
        "JOIN customers c ON b.customer_id = c.customer_id "
        "WHERE b.booking_id = ?";

    if (!adminMode) {
        query += " AND b.customer_id = ?";
    }

    unique_ptr<sql::PreparedStatement> ps(con->prepareStatement(query));
    ps->setInt(1, bookingId);

    if (!adminMode) {
        ps->setInt(2, currentCustomerId);
    }

    unique_ptr<sql::ResultSet> rs(ps->executeQuery());

    if (!rs->next()) {
        cout << "Booking not found.\n";
        return;
    }

    cout << "\n========== HOTEL BILL ==========\n";
    cout << "Booking ID: " << rs->getInt("booking_id")
         << "\nCustomer: " << rs->getString("name")
         << "\nRoom ID: " << rs->getInt("room_id")
         << "\nDays: " << rs->getInt("days")
         << "\nRoom Charges: Rs. " << rs->getDouble("total_bill")
         << "\nBooking Status: " << rs->getString("status")
         << "\n================================\n";
}

// ---------------- MENUS ----------------

void userMenu() {
    createCustomerProfile();

    while (true) {
        cout << "\n========== USER MENU ==========\n"
             << "1. View Available Rooms\n"
             << "2. Search Room Type\n"
             << "3. Search AC/Non-AC Rooms\n"
             << "4. Search Type and AC Category\n"
             << "5. Book Room\n"
             << "6. View My Bookings\n"
             << "7. Cancel My Booking\n"
             << "8. View My Bill\n"
             << "0. Logout\n";

        int choice = readInt("Enter choice: ");

        switch (choice) {
            case 1: searchAvailableRooms(); break;
            case 2: searchRoomType(); break;
            case 3: searchACCategory(); break;
            case 4: searchTypeAndCategory(); break;
            case 5: bookRoom(); break;
            case 6: viewBookings(false); break;
            case 7: cancelBooking(false); break;
            case 8: generateBill(false); break;
            case 0: return;
            default: cout << "Invalid choice.\n";
        }
    }
}

void adminMenu() {
    while (true) {
        cout << "\n========== ADMIN MENU ==========\n"
             << "1. View All Customers\n"
             << "2. Search Customer\n"
             << "3. View All Rooms\n"
             << "4. View Available Rooms\n"
             << "5. Search Room Type\n"
             << "6. Search AC/Non-AC Rooms\n"
             << "7. Search Type and AC Category\n"
             << "8. Add Room\n"
             << "9. Book Room for My Account\n"
             << "10. View All Bookings\n"
             << "11. Cancel Booking\n"
             << "12. Check Out\n"
             << "13. Generate Bill\n"
             << "14. Create User/Admin Account\n"
             << "0. Logout\n";

        int choice = readInt("Enter choice: ");

        switch (choice) {
            case 1: displayCustomers(); break;
            case 2: searchCustomer(); break;
            case 3: displayAllRooms(); break;
            case 4: searchAvailableRooms(); break;
            case 5: searchRoomType(); break;
            case 6: searchACCategory(); break;
            case 7: searchTypeAndCategory(); break;
            case 8: addRoom(); break;
            case 9:
                createCustomerProfile();
                bookRoom();
                break;
            case 10: viewBookings(true); break;
            case 11: cancelBooking(true); break;
            case 12: checkOut(); break;
            case 13: generateBill(true); break;
            case 14: registerUser(true); break;
            case 0: return;
            default: cout << "Invalid choice.\n";
        }
    }
}

// ---------------- MAIN ----------------

int main() {
    try {
        connectDatabase();

        while (true) {
            cout << "\n====================================\n"
                 << "      HOTEL MANAGEMENT SYSTEM\n"
                 << "====================================\n"
                 << "1. Admin Login\n"
                 << "2. User Login\n"
                 << "3. Register New User\n"
                 << "0. Exit\n";

            int choice = readInt("Enter choice: ");

            if (choice == 0) {
                cout << "Thank you for using the system!\n";
                break;
            }

            if (choice == 3) {
                registerUser(false);
                continue;
            }

            if (choice != 1 && choice != 2) {
                cout << "Invalid choice.\n";
                continue;
            }

            if (!login()) {
                continue;
            }

            if (choice == 1 && currentRole != "admin") {
                cout << "Access denied. Admin account required.\n";
            } else if (choice == 2 && currentRole != "user") {
                cout << "This is an admin account. Select Admin Login.\n";
            } else if (currentRole == "admin") {
                adminMenu();
            } else {
                userMenu();
            }

            currentUsername.clear();
            currentRole.clear();
            currentUserId = 0;
            currentCustomerId = 0;
        }

    } catch (sql::SQLException& e) {
        cerr << "Database error: " << e.what() << "\n";
    } catch (exception& e) {
        cerr << "Error: " << e.what() << "\n";
    }

    return 0;
}
