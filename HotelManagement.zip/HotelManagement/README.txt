HOTEL MANAGEMENT SYSTEM (C++ + MySQL)

Files:
- hotel.cpp      : C++ source code
- setup.sql      : Database and table setup
- README.txt     : Setup notes

SETUP
1. Install MySQL Server and MySQL Connector/C++.
2. Install OpenSSL development files compatible with your C++ compiler.
3. Open setup.sql in MySQL Workbench and execute it.
4. Open hotel.cpp in VS Code.
5. Replace YOUR_MYSQL_PASSWORD with your MySQL password.
6. Configure the MySQL Connector/C++ and OpenSSL include/library paths in your build settings.
7. Compile and link against the installed MySQL Connector/C++ and OpenSSL libraries.

IMPORTANT
- This is an educational starter project. It uses SHA-256 only as a demonstration hash;
  SHA-256 alone is not appropriate for production password storage. Use Argon2id or bcrypt
  with a unique salt in a real application.
- The public registration menu creates user accounts only.
- To create the first admin, register an account, then run this SQL command as your
  database administrator (replace the username):
    UPDATE users SET role = 'admin' WHERE username = 'YOUR_CHOSEN_USERNAME';
- Do not publish your database password or commit it to a public repository.
- If you already have older versions of the tables, back up the database and migrate
  the schema before running setup.sql.
